enum class TipoUsuario {
    VISITANTE, SOCIO, TERCERA_EDAD
}


enum class TipoEquipo {
    CARDIO, FUERZA, FUNCIONAL
}


enum class EstadoPuesto {
    LIBRE, EN_USO, EN_PROCESO, EN_MANTENCION
}


object ValidadorSistema {

    private val regexCodigo = Regex("^[A-Za-z]{2}\\d{2}[A-Za-z]{2}$")

    fun esCodigoValido(codigo: String): Boolean {
        return codigo.matches(regexCodigo)
    }
}