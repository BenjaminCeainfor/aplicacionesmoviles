class TarifaInvalidaException(mensaje: String) : Exception(mensaje)

class GestorTarifas {

    var recaudacionTotal: Double = 0.0
    val recaudacionPorTipo: MutableMap<TipoEquipo, Double> = mutableMapOf(
        TipoEquipo.CARDIO to 0.0,
        TipoEquipo.FUERZA to 0.0,
        TipoEquipo.FUNCIONAL to 0.0
    )

    fun procesarCobro(equipo: Equipo, minutosUso: Int): Double {
        try {

            val costoBase = equipo.calcularCostoBase(minutosUso)

